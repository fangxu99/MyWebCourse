# Demo Chapter 06 - Browserify with CommonJS Modules
## Overview: Follow the steps to see Browserify in action

1. Use `npm install` to get the dependencies

1. Use `npm run build` to execute the build script
notice the file created in the dist directory

1. Open the `text.html` in Chrome and IE