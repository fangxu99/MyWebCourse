export default function (array) {
	return array.join(", ");
}


