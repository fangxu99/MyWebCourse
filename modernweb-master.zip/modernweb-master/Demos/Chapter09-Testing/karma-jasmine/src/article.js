export function Article() {
    this.title = 
      "Lab Mice Strike for Improved Working Conditions, Benefits"
  }