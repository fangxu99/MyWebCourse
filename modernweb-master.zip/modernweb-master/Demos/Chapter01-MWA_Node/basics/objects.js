let aMusician = {
    name: 'Les Claypool',
    instrument: 'Bass',
    bands: ['Primus','Oysterhead']
}

console.log(aMusician);

console.log(aMusician.name + ' plays ' + 
        aMusician.instrument + ' in ' + aMusician.bands[1]);


        