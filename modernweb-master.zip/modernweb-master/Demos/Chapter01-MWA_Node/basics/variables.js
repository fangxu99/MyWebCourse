let musicianName = 'Buckethead';
let instrument = 'guitar';
let bands = [ 'Praxis',
              "Guns 'N Roses",
              `Colonel Claypool's "Bucket of Bernie Brains"`];
