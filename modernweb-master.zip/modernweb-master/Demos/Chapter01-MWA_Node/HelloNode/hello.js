//open the directory from a command window or terminal
//type node hello.js
let z = 3 * 8;

let today = new Date();

console.log('Hello', z, today);