
// All pages
$('body').css('color', 'navy');
$('.container').css('width', '75%');

// Index Page
$('.buttons').css({'display': 'block', 'margin': 'auto', 'width': '15%'});

// Add Page
$('form').css({'width': '500px', 'margin': '0 auto'});
$('input').css('width', '100%');