let [first, last] = ['Les','Claypool'];

//instead of 
// data = ['Les','Claypool'];
// let first = data[0]
// let last = data[1]
