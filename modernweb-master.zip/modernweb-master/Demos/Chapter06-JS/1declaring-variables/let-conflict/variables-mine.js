let myFavoriteMusician = 'Les Claypool';
