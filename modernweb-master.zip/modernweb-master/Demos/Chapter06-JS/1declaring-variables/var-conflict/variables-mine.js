var myFavoriteMusician = 'Les Claypool';
