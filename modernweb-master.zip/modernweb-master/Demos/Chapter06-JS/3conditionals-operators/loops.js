for (var counter = 0; counter < 3; counter++) {
    console.log('BeetleJuice');
    for (var counter = 0; counter < 3; counter++) {
        console.log(counter);
    }
}

let z = 10;
console.log('z stuff');
for (z = 0; z < 3; z++) {
    console.log(z); 
}

console.log(z);

// for (var countdown = 10; countdown > 0; countdown--) {
//     console.log(`${countdown}...`);
// }

// console.log(`What is countdown now? ${countdown}`)

