# Chapter 6: Demo: AJAX JSON Data

## Objective
* View the usage of AJAX

## Steps:

1. At the same level as the package.json do an `npm install` and `npm start`

2. The output gives a URL, follow this link

3. Click the link `Load Bands from JSON file`.

4. Explore the code in `loadBands.html`

5. How is the AJAX call made?



