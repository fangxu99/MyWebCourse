# CSS3 Techniques

1. Open the file `css3.html` in this folder in both the editor and browser

1. Read the text in the browser and click the link to see the effect you will be creating

1. In the editor, make changes the `css3.html` file to reproduce what you see in the browser

1. For `.inner-box`, add an `opacity`,  `border-radius` and `box-shadow`

1. Create an `.inner-box:hover` to make a red background and white text

