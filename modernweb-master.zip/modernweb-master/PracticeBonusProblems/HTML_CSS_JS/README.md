# Extra Practice: A page about you

## Objectives
* Use HTML to create 3 pages

## Steps:
1. Use HTML to create a home page with Hello,
and navigation to 3 pages, friends, family, hobbies.

1. Use CSS to style the navigation with over effects.

1. Use JS to load the data dynamically.

A partial solution is given for HTML and CSS

