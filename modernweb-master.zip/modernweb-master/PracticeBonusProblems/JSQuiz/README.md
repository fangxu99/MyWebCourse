# Extra Practice: JS Quiz

## Objectives
* Make the CSS Quiz more dynamic by loading the questions using JS

## Steps:
1. First Complete the Extra Practice readme in `CSSQuiz` 

1. In JS hard code arrays of questions and answers.
    * Or use an array of objects with Q & A

1. Using a loop, and DOM manipulation, populate the Q & A sections with JS.

