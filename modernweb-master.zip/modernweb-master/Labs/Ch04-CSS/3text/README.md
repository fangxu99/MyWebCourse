# Chapter 4: Working with Text properties
 
### Estimated Completion Time 
5 minutes

1. If you needed to step away or otherwise did not finish the exercise, you can rename or delete your folder, and copy the solution from last exercise into your project directory to continue from there.

1. Continue working in `LoremIpsum` 

1. Center align the content of the header. Resize your browser and see how it adjusts. If you need a hint, or to continue, scroll down.

    ```






































    ```
    ```CSS
    header {text-align:center}
    ``` 

1. Remove the bullets from the nav links
    ```






































    ```
    ```CSS
    nav ul li {list-style:none}
    ``` 

1. The underlining of links looks strange for navigation, turn this off. 
    ```






































      ```
      ```CSS
      nav a {text-decoration:none}
      ``` 

1. Mark your work as complete