# Chapter 4: Order is important!

### Estimated Completion Time 
5 minutes
 
1. If you needed to step away or otherwise did not finish the exercise, you can rename or delete your folder, and copy the solution from last exercise into your project directory to continue from there. 

1. Continue working in `LoremIpsum` 

1. It is no longer fake Halloween - comment out that stylesheet.


1. Style the links in the nav tag (can refer to slides)
    * Set the normal state to have a white text color and background color of red
    * On a hover switch the two 
    * Keep in mind LoVe HAte

