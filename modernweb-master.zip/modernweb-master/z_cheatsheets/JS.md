## Browse these fine cheatsheets

* http://htmlcheatsheet.com/js/
* https://github.com/mbeaudru/modern-js-cheatsheet
