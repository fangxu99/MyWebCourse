## quick saves:
Ctrl + S

## Undo
Ctr + Z

## copy
Ctrl + C

## paste
Ctrl + V
