## Install by reading package.json
npm install

## Install a package and add to devDependencies
npm install name-of-package -D

## Install a package and add to Dependencies
npm install name-of-package -S

## npx path message
* https://github.com/zkat/npx/issues/168
* https://github.com/npm/npm/commit/c8230c9bbd596156a4a8cfe62f2370f81d22bd9f

##troubleshooting latest npm
* https://docs.npmjs.com/troubleshooting/try-the-latest-stable-version-of-npm

