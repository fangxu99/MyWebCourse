cd = change directory
./ = current directory
../ = up one directory
ls = list files
dir = windows list of files

ls -la = long list format and don't hide files starting with .
pwd = print working directory
mkdir = create a new directory
cp [source] [dest] = copy
mv [source] [dest] = move, or rename
rm = remove files or directories
help = get bash commands
-help = get help with a command
