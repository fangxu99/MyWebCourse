## Browse these cheatsheets

* https://www.toptal.com/css/css-cheat-sheet
* https://websitesetup.org/css3-cheat-sheet/
* https://cssauthor.com/html-and-css-cheat-sheets/
* http://htmlcheatsheet.com/css/ 

http://www.colorzilla.com/gradient-editor/ 