MarkDown Resources
===================

* https://github.com/adam-p/markdown-here/wiki/Markdown-Here-Cheatsheet
* https://help.github.com/categories/writing-on-github/

* View in Preview mode:
    * ⇧⌘V   or control-shift-V