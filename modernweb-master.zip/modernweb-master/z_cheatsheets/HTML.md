## Browse these fine cheatsheets

* https://websitesetup.org/html5-cheat-sheet/

Emmett abbreviations cheatsheet
https://docs.emmet.io/cheat-sheet/

